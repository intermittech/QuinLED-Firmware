Import('env')

env.Execute("npm run build")