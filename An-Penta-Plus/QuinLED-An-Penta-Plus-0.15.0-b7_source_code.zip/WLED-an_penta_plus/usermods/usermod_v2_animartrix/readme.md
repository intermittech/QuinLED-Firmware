# ANIMartRIX

Addes the effects from ANIMartRIX to WLED

CC BY-NC 3.0 licensed effects by Stefan Petrick, include this usermod only if you accept the terms!

## Installation 

Please uncomment the two references to ANIMartRIX in your platform.ini 

lib_dep to a version of https://github.com/netmindz/animartrix.git
and the build_flags  -D USERMOD_ANIMARTRIX


