## Word clock usermod

By @bwente

See https://www.hackster.io/bwente/word-clock-with-just-two-components-073834 for the hardware guide!<br/>
Includes a customizable feature to reduce the brightness at night.

![image](https://user-images.githubusercontent.com/371964/197094071-f8ccaf59-1d85-4dd2-8e09-1389675291e1.png)


![image](https://user-images.githubusercontent.com/371964/197094211-6c736257-95ff-491f-9f0d-35d5135ecfea.png)





![mini_8x8_word_clock_reverse_stencil_sZFti6chj4(1)](https://user-images.githubusercontent.com/371964/197094410-7c275f3f-743b-477a-bc15-5e7bdbcbd833.svg)

![mini_8x8_word_clock_box_epUWJOBOhr(1)](https://user-images.githubusercontent.com/371964/197094496-fa49b355-164b-4bf5-84fd-f22f5206c645.svg)
